﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nicol_herencia
{
    public class personal_dservicios :estudiantes
    {
        public string incorporacion_facu { get; set; }
        public string campodespacho { get; set; }

        public personal_dservicios (string incorporacion_facu, string campodespacho, string nombre, string apellido, string cedula, string estadocivil) : base(nombre, apellido, cedula, estadocivil)
        {
            this.incorporacion_facu = incorporacion_facu;
            this.campodespacho = campodespacho;
        }

        public void imprimiendopersonal_dservicios()
        {
            Console.WriteLine("campodespacho" + campodespacho);
        }

        public string getcampodespacho()
        {
            return campodespacho;
        }
        public void setcampodespacho (string campodespácho)
        {
            this.campodespacho = campodespacho;
        }
    }
}
