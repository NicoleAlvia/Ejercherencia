﻿using System;

namespace Nicol_herencia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            estudiantes estudiantes = new estudiantes("karen", "alonzo", "1310984975", "soltera");
            estudiantes.setnombre("keren");
            estudiantes.setapellido("alonzo");
            estudiantes.setcedula("1310984975");
            estudiantes.setestadocivil("soltera");
            Console.WriteLine(estudiantes.getnombre() + estudiantes.getapellido() + estudiantes.getcedula() + estudiantes.getestadocivil());

            profesores profesores = new profesores("matematicas", "willians", "alonzo", "1310984975", "casado");
            profesores.setdepartamento("matematicas");
            profesores.setnombre("willians");
            profesores.setapellido("alanzo");
            profesores.setcedula("1310984975");
            profesores.setestadocivil("casado");
            Console.WriteLine(profesores.getdepartamento() + profesores.getnombre() + profesores.getapellido() + profesores.getcedula() + profesores.getestadocivil());

            personal_dservicios personal_dservicios = new personal_dservicios("220/10/10", "secretario", "matematicas", "willians", "alonzo", "1310984975");
            personal_dservicios.setcampodespacho("matematicas");
            personal_dservicios.setnombre("willians");
            personal_dservicios.setapellido("alanzo");
            personal_dservicios.setcedula("1310984975");
            personal_dservicios.setestadocivil("casado");
            Console.WriteLine(profesores.getdepartamento() + profesores.getnombre() + profesores.getapellido() + profesores.getcedula() );  


        }
    } 
}

    
